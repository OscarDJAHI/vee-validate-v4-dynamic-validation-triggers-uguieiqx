<template>
  <h1>Ressources S3</h1>
</template>
