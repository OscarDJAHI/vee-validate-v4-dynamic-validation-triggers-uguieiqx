<script lang="ts" setup>
import { ref } from 'vue'
import type { DsfrDataTableProps } from '@gouvminint/vue-dsfr'

const headers: DsfrDataTableProps['headersRow'] = [
  {
    key: 'id',
    label: 'ID',
  },
  {
    key: 'name',
    label: 'Name',
  },
  {
    key: 'email',
    label: 'Email',
  },
]

const rows = [
  [1, 'John Doe', 'john.doe@gmail.com'],
  [2, 'Jane Doe', 'jane.doe@gmail.com'],
  [3, 'James Bond', 'james.bond@mi6.gov.uk'],
]

const click = (event: MouseEvent, key: string) => {
  console.warn(event, key)
}

const selection = ref<string[]>([])
</script>

<template>
  <!-- <div class="fr-container fr-my-2v"> -->
  <div class="fr-mr-3w">
    <DsfrDataTable
      v-model:selection="selection"
      title="Dashboard"
      :headers-row="headers"
      :rows="rows"
      sortable-rows
      row-key="id"
      vertical-borders
      class="fr-fluid"
    >
      <template #header="{ key, label }">
        <div @click="click($event, key)">
          <em>{{ label }}</em>
        </div>
      </template>

      <template #cell="{ colKey, cell }">
        <template v-if="colKey === 'email'">
          <a :href="`mailto:${cell as string}`">{{ cell }}</a>
        </template>
        <template v-else>
          {{ cell }} <em>({{ colKey }})</em>
        </template>
      </template>
    </DsfrDataTable>
    IDs sélectionnées : {{ selection }}
  </div>
</template>
<style>
:deep(table) {
  width: 100% !important;
}
:deep(tbody){
  width: 100% !important;
}
:deep(.fr-table > table){
  display: inline-table;
}
:deep(table tr td){
  cursor: pointer;
  background-color: transparent;
  background-image: linear-gradient(0deg,var(--border-contrast-grey),var(--border-contrast-grey)),linear-gradient(0deg,var(--border-contrast-grey),var(--border-contrast-grey));
}
:deep(.fr-table > table > thead > tr > td:nth-last-child(-n+3)){
  padding: 0 !important;
}
:deep(.table-action-button){
  padding: 0 !important;
  margin: 0 4px;
  max-height: 18px !important;
  height: 18px !important;
  min-height: 18px !important;
  justify-content: center;
  align-items: center;
}
:deep(.table-action-button:before){
  padding: 0 !important;
  margin: 0 !important;
  max-height: 18px !important;
  height: 18px !important;
  min-height: 18px !important;
  justify-content: center;
  align-items: center;
}
:deep(.fr-table > table > thead > tr > th:nth-last-child(-n+3)){
  padding: 0 !important;
}

</style>