import { createRouter, createWebHistory } from 'vue-router'

import Home from '../views/AppHome.vue'
import AboutUs from '../views/AboutUs.vue'
import Dashboard from '../views/Dashboard.vue'
import Project from '../views/Project.vue'
import Tenant from '../views/Tenant.vue'
import Cluster from '../views/Cluster.vue'
import Namespace from '../views/Namespace.vue'
import Admin from '../views/admin/Admin.vue'

const MAIN_TITLE = 'Gabarit de démarrage VueDsfr'

const routes = [
  {
    path: '/',
    name: 'home',
    component: Home,
  },
  {
    path: '/a-propos',
    name: 'about',
    component: AboutUs,
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    component: Dashboard,
  }, 
  {
    path: '/project',
    name: 'project',
    component: Project,
  }, 
  {
    path: '/tenant',
    name: 'resource-iaas',
    component: Tenant,
  }, 
  {
    path: '/cluster',
    name: 'resource-caas',
    component: Cluster,
  },
  {
    path: '/namespace',
    name: 'resource-s3',
    component: Namespace,
  },
  {
    path: '/admin',
    name: 'admin',
    component: Admin,
  },
  // {
  //   path: '/rubrique-2/sous-rubrique-1',
  //   name: 'admin',
  //   component: Admin,
  // },
  // {
  //   path: '/rubrique-2/sous-rubrique-2/sous-sous-rubrique-1',
  //   name: 'sub-admin',
  //   component: Admin,
  // },
  // {
  //   path: '/admin',
  //   name: 'administration',
  //   children: [
  //     {
  //       // path: '/sub-admin',
  //       path: '/admin/sub-admin',
  //       name: 'admin',
  //       component: Admin,
  //     },
  //   ] 
  // },
]

const router = createRouter({
  history: createWebHistory(import.meta.env?.BASE_URL || ''),
  routes,
})

router.beforeEach((to) => { // Cf. https://github.com/vueuse/head pour des transformations avancées de Head
  const specificTitle = to.meta.title ? `${to.meta.title} - ` : ''
  document.title = `${specificTitle}${MAIN_TITLE}`
})

export default router
