<script setup lang="ts">
import { useRegisterSW } from 'virtual:pwa-register/vue'

import useToaster from './composables/use-toaster'

const toaster = useToaster()

const serviceTitle = 'Service'
const serviceDescription = 'Description du service'
const logoText = ['Ministère', 'de l’intérieur']

const quickLinks = [
  {
    label: 'Home',
    to: '/',
    icon: 'ri-home-4-line',
    iconAttrs: { color: 'var(--red-marianne-425-625)' },
  },
  {
    label: 'À propos',
    to: '/a-propos',
    icon: 'ri-question-mark',
    iconRight: true,
  },
]
const searchQuery = ref('')

const {
  offlineReady,
  needRefresh,
  updateServiceWorker,
} = useRegisterSW()

function close () {
  offlineReady.value = false
  needRefresh.value = false
}
</script>

<template>
  <DsfrHeader
    v-model="searchQuery"
    :service-title="serviceTitle"
    :service-description="serviceDescription"
    :logo-text="logoText"
    :quick-links="quickLinks"
    show-search
  />

  <div class="fr-container-fluid fr-grid-row">
    <aside class="fr-col-2" aria-labelledby="fr-sidemenu-title">
      <side-menu></side-menu>
    </aside>
    <div class="fr-col-10">
      <router-view />
    </div>
    <!-- <router-view /> -->
  </div>

  <ReloadPrompt
    :offline-ready="offlineReady"
    :need-refresh="needRefresh"
    @close="close()"
    @update-service-worker="updateServiceWorker()"
  />

  <!-- <AppToaster
    :messages="toaster.messages"
    @close-message="toaster.removeMessage($event)"
  /> -->
</template>
