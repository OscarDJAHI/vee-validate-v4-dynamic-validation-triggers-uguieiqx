<script lang="ts" setup>
const route = useRoute()

const headingTitle = 'Titre de la rubrique'
const menuItems = computed(() => [
  {
    id: '10',
    to: '/dashboard',
    text: 'Dashboard',
    active: route.name === 'dashboard',
  },
  {
    id: '11',
    to: '/project',
    text: 'Projets',
    active: route.name === 'project',
  },
  {
    id: '12',
    to: '/tenant',
    text: 'Services Iaas',
    active: route.name === 'resource-iaas',
  },
    {
    id: '13',
    to: '/cluster',
    text: 'Clusters Openshift',
    active: route.name === 'resource-caas',
  },
  {
    id: '14',
    to: '/namespace',
    text: 'Namespaces S3',
    active: route.name === 'resource-s3',
  },
  // {
  //   id: '15',
  //   to: '/admin',
  //   text: 'admin',
  //   active: route.name === 'admin',
  // },
  {
    id: '16',
    text: 'Administration',
    active: true,
    menuItems: [
      {
        id: '21',
        to: '/rubrique-2/sous-rubrique-1',
        text: 'Premier titre de niveau 2',
      },
      {
        id: '22',
        text: 'Deuxième titre de niveau 2',
        active: true,
        menuItems: [
          {
            id: '31',
            to: '/rubrique-2/sous-rubrique-2/sous-sous-rubrique-1',
            text: 'Premier titre de niveau 3',
          },
        ],
      },
    ],
  },
])

</script>

<template>
  <div class="fr-ml-2v">
    <!-- <div>{{ route.name }}</div> -->
    <DsfrSideMenu
      :menu-items="menuItems"
    />
  </div>
</template>